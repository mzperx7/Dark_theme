@echo off

if "%1"=="clean" (
    echo Cleaning up files...
    del *.exe
    del *.ilk
    del *.obj
    del *.pdb
    echo ...clean up complete.
    exit /B
)

setlocal enabledelayedexpansion

set SRC=main.c hash.c init.c std.c
set OUTPUT_EXE=main.exe
set JSON_FILE=compile_commands.json

set INCS=/I../msvc/libraries/freetype/include
set LIBPATH=/LIBPATH:../msvc/libraries/freetype
set LIBS=freetype.lib Shell32.lib User32.lib Gdi32.lib Shcore.lib

REM Create compile_commands.json
echo [ > %JSON_FILE%

REM Initialize a counter
set COUNT=0
for %%F in (%SRC%) do (
    set /a COUNT+=1
    set COMMAND="clang-cl.exe %%F /Zi %INCS% /c"

    REM Add command to JSON array
    if !COUNT! gtr 1 (
        echo , >> %JSON_FILE%
    )
    echo { >> %JSON_FILE%
    set DIR=%CD:\=/%
    echo "directory": "!DIR!", >> %JSON_FILE%
    echo "command": !COMMAND!, >> %JSON_FILE%
    echo "file": "%%F" >> %JSON_FILE%
    echo } >> %JSON_FILE%
)

echo ] >> %JSON_FILE%

REM DEBUG - note /fsanitize=address works only with cl.exe
clang-cl.exe /Oi /Zi %INCS% %SRC% /link /SUBSYSTEM:WINDOWS /DEBUG:FULL %LIBPATH% %LIBS% /OUT:%OUTPUT_EXE%

REM RELEASE
REM cl.exe /O2 %INCS% %SRC% /link /SUBSYSTEM:WINDOWS %LIBPATH% %LIBS% /OUT:%OUTPUT_EXE%

endlocal
